package br.com.oficina.controle;

public interface InterfaceControle {
    final String usuario = "postgres";
    final String senha = "postgres";
    final String endereco = "localhost/oficina";
}
